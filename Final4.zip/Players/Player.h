#pragma once
#include "ostream"
#define DEFAULT_MAX_HP 100
#define DEFAULT_FORCE 5
#define MAX_LEVEL 10
#define DEFAULT_LEVEL 1
#define DEFAULT_COINS 10
#define MAX_HP 100

using std::string;


class Player {
private:


    std :: string m_name;
    int m_level;
    int m_force;
    int m_hp;
    int m_coins;
    std::string m_behavior;


public:
    /**
     * C'Tors & D'Tors
     */
    explicit Player(const string &name, const std::string &behavior);
    Player(const Player&);
    virtual ~Player() = default;
    Player& operator=(const Player&);

    /**
     * Gets the description of the player
     * 
     * @return - description of the player
    */
    virtual string getDescription() const = 0;

    /**
     * Gets the name of the player
     * 
     * @return - name of the player
    */
    string getName() const;

    /**
     * Gets the current level of the player
     * 
     * @return - level of the player
    */
    int getLevel() const;

    /**
     * Gets the of force the player has
     * 
     * @return - force points of the player
    */
    int getForce() const;

    /**
     * Gets the amount of health points the player currently has
     * 
     * @return - health points of the player
    */
    int getHealthPoints() const;

    /**
     * Gets the amount of coins the player has
     * 
     * @return - coins of the player
    */
    int getCoins() const;

    /**
     * Calculates the player's Attack Strength
     * @return The player Attack Strength
     */
    virtual int getCombatPower() const = 0;

    /**
     *
     * @return the player's behavior
     */
    string getBehavior() const;


    /**
     *
     * @return the player's job
     */
    virtual string getJob() const = 0;

    /**
     * Methods
     */

    /**
     * Increases the player level by 1
     */
    void levelUp();

    /**
     * Increases the player buff by force_value
     * @param force_value the amount of force to add
     */
    virtual void buff(int force_value);

    /**
     * Increases the player health by heal_value
     * @param heal_value
     */
    virtual void heal(int heal_value);

    /**
     * Checks if the player hp is equal to zero
     * @return false if the player health is grater than zero
     */
    bool isKnockedOut() const;

    /**
     * Decreases the player coins by cost
     * @param cost The value we want to decrease it from the coins
     * @return
     */
    bool pay(int cost);

    /**
     * Decreases the player HP by damage_value
     * @param damage_value The value we want to decrease it from the HP
     * @return The new HP
     */
    void damage(int damage_value);

    /**
     * Increases the player coins by coins
     * @param coins The value we want to add it to the coins
     * @return The new coins
     */
    int addCoins(int coins);

    /**
    * Checks if the player won
    * @return true if the player's level equals to MAX_LEVEL
    */
    bool winner() const;



};
