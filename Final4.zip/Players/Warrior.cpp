//
// Created by Mohanad Riead on 3/19/2024.
//

#include "Warrior.h"


Warrior::Warrior(const std::string &name, const std::string &behavior) : Player(name, behavior){}

int Warrior::getCombatPower() const{
    int combatPower = getForce() * 2 + getLevel();
    return combatPower;
}

std::string Warrior::getDescription() const{
    std::string str = getName() + ", Warrior with " + getBehavior() +
                      " behavior (level " + std::to_string(getLevel()) +
                      ", force " + std::to_string(getForce()) + ")";
    return str;
}


std::string Warrior::getJob() const{
    return "Warrior";
}

