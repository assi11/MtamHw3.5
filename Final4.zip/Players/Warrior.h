//
// Created by Mohanad Riead on 3/19/2024.
//

#ifndef PLAYERS_WARRIOR_H
#define PLAYERS_WARRIOR_H
#include "Player.h"


class Warrior : public Player{

public:
    explicit Warrior(const std::string &name, const std::string &behavior);
    int getCombatPower() const override;
    string getDescription() const override;

    std::string getJob() const override;

};



#endif //PLAYERS_WARRIOR_H
