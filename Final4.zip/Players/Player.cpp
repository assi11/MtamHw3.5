//
// Created by Mohanad Riead on 3/19/2024.
//
#include "Player.h"


/**
 * C'Tors & D'Tors
 */
 Player::Player(const std::string& name, const std::string &behavior){
     m_name = name;
     m_level = DEFAULT_LEVEL;
     m_force = DEFAULT_FORCE;
     m_hp = DEFAULT_MAX_HP;
     m_coins = DEFAULT_COINS;
     m_behavior = behavior;
 }

 Player::Player(const Player& other){
    m_name = other.m_name;
    m_level = other.m_level;
    m_force = other.m_force;
    m_hp = other.m_hp;
    m_coins = other.m_coins;
    m_behavior = other.m_behavior;

 }

 Player& Player::operator=(const Player &other){
    if(this == &other){
        return *this;
    }
    m_name = other.m_name;
    m_level= other.m_level;
    m_force = other.m_force;
    m_hp = other.m_hp;
    m_coins = other.m_coins;
    m_behavior = other.m_behavior;
     return *this;
 }

/**
   ------Getters------
*/
 string Player::getName() const{
    return this->m_name;
}

int Player::getLevel() const{
    return m_level;
}

int Player::getForce() const {
    return m_force;
}

int Player::getHealthPoints() const{
    return m_hp;
}

int Player::getCoins() const{
    return m_coins;
}



string Player::getBehavior() const{
    return m_behavior;
}

/**
    ------Methods------
*/
void Player::levelUp(){
    if(m_level < 10){
        m_level++;
    }
}

void Player::buff(int force_value){
     m_force += force_value;
     if(m_force <= 0){
         m_force = 0;
     }
 }

void Player::heal(int heal_value){
        m_hp += heal_value;
        if(m_hp > MAX_HP){
            m_hp = MAX_HP;
        }
        if(m_hp <= 0){
            m_hp = 0;
        }
 }

bool Player::isKnockedOut() const{
    if(m_hp <= 0){
        return true;
    }
    return false;
 }

bool Player::pay(int cost){
    if(cost > m_coins){
        return false;
    }
    m_coins -= cost;
    return true;
 }

void Player::damage(int damage_value){
    if(damage_value <= 0){
        return;
    }
    m_hp -= damage_value;
    if(m_hp < 0){
        m_hp = 0;
    }
 }

 int Player::addCoins(int coins) {

     return m_coins += coins;
}

bool Player::winner() const{
    if(m_level >= MAX_LEVEL){
        return true;
    }
    return false;
}



