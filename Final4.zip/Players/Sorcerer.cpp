//
// Created by Mohanad Riead on 3/19/2024.
//

#include "Sorcerer.h"
Sorcerer :: Sorcerer(const std::string &name, const std::string &behavior): Player(name, behavior){}

std::string Sorcerer::getDescription() const{
    std::string str = getName() + ", Sorcerer with " + getBehavior() +
                      " behavior (level " + std::to_string(getLevel()) +
                      ", force " + std::to_string(getForce()) + ")";

    return str;
}

std::string Sorcerer::getJob() const{
    return "Sorcerer";
}

int Sorcerer::getCombatPower() const{

    int combatPower = getForce() + getLevel();
    return combatPower;

}

