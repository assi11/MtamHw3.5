//
// Created by Mohanad Riead on 3/19/2024.
//

#ifndef PLAYERS_SORCERER_H
#define PLAYERS_SORCERER_H
#include "Player.h"


#include <string>

class Sorcerer : public Player{
public :
    explicit Sorcerer(const std::string &name, const std::string &behavior);
    std::string getDescription() const override;
    std::string getJob() const override;
    int getCombatPower() const override;

};


#endif //PLAYERS_SORCERER_H
