#include "Mtmchkin.h"
#include "utilities.h"
#include <iostream>
#include <fstream>
#include <memory>
#include <stdexcept>
#include <string>
#include <cctype>
#include <algorithm>
#include <sstream>

const int MAX_NAME_LENGTH = 15;
const int MIN_NAME_LENGTH = 3;
const int MAX_PLAYERS_SIZE = 6;
const int MIN_PLAYER_SIZE = 2;
const int MIN_CARDS_SIZE = 2;
const char EMPTY = ' ';

bool checkFileFormat(const std::string filepath) {
    std::ifstream inputFile(filepath);

    if (!inputFile.is_open()) {
        throw std::runtime_error("Failed to open file");
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        std::istringstream iss(line);
        std::string word;
        int wordCount = 0;
        while (iss >> word) {
            wordCount++;
        }
        if (wordCount != 3) {
            inputFile.close();
            throw std::runtime_error("Invalid Players File");
        }
    }

    inputFile.close();
    return true;
}

bool Mtmchkin::isValidName(const std::string& name) {
    if (name.length() < MIN_NAME_LENGTH || name.length() > MAX_NAME_LENGTH) {
        return false;
    }
    for(char letter : name) {
        if (!std::isalpha(letter)) {
            return false;
        }
    }
    return true;
}


void Mtmchkin::readPlayersFromFile(const std::string& filename) {
    std::ifstream inputFile(filename);

    if (!inputFile.is_open()) {
        throw std::runtime_error("Invalid Players File");
    }
    checkFileFormat(filename);

    std::string name, job, behavior;

    while (inputFile >> name >> job >> behavior) {
        if (!isValidName(name)) {
            throw std::runtime_error("Invalid Players File");
        }
        if (behavior != "Responsible" && behavior != "RiskTaking") {
            throw std::runtime_error("Invalid Players File");
        }

        if (job == "Warrior") {
            v_players.push_back(std::unique_ptr<Warrior>(new Warrior(name, behavior)));
        } else if (job == "Sorcerer") {
            v_players.push_back(std::unique_ptr<Sorcerer>(new Sorcerer(name, behavior)));
        } else {
            throw std::runtime_error("Invalid Players File");
        }
    }

    if (v_players.size() < MIN_PLAYER_SIZE || v_players.size() > MAX_PLAYERS_SIZE) {
        throw std::runtime_error("Invalid Players File");
    }

    std::string extraLineCheck;
    if (inputFile >> extraLineCheck) {
        throw std::runtime_error("Invalid Players File");
    }

    inputFile.close();
}


bool Mtmchkin::readWordsCards(const std::string& filename,std::vector<std::string>& string_cards) {
    std::ifstream inputFile(filename);
    if (!inputFile) {
        throw std::runtime_error("Invalid Cards File");
    }
    std::string line;
    std::string new_card;
    while (std::getline(inputFile, line)) {
        for (char c: line) {
            if (c == ' ' && !new_card.empty()) {
                string_cards.push_back(new_card);
                new_card.clear();
            } else {
                if (c != ' ' && c != '\r') {
                    new_card += c;
                }
            }
        }

        if (!new_card.empty()) {
            string_cards.push_back(new_card);
            new_card.clear();
        }
    }
    inputFile.close();
    return true;
}

bool Mtmchkin::readCardsFromFile(std::vector<std::string> &string_cards) {
    int gang_num = 0;
    while (string_cards.size()>0){
        if (string_cards.front() == "Dragon") {
            v_cards.push_back(std::unique_ptr<Card>(new Dragon()));
            string_cards.erase(string_cards.begin());
            continue;
        } else if (string_cards.front()  == "Giant") {
            v_cards.push_back(std::unique_ptr<Card>(new Giant()));
            string_cards.erase(string_cards.begin());
            continue;
        } else if (string_cards.front()  == "Goblin") {
            v_cards.push_back(std::unique_ptr<Card>(new Goblin()));
            string_cards.erase(string_cards.begin());
            continue;
        } else if (string_cards.front()  == "SolarEclipse") {
            v_cards.push_back(std::unique_ptr<Card>(new SolarEclipse()));
            string_cards.erase(string_cards.begin());
            continue;
        } else if (string_cards.front()  == "PotionsMerchant") {
            v_cards.push_back(std::unique_ptr<Card>(new PotionsMerchant()));
            string_cards.erase(string_cards.begin());
            continue;
        } else {
            if (string_cards.front()  == "Gang") {
                string_cards.erase(string_cards.begin());
                for (auto c: string_cards.front() ) {
                    if (!std::isdigit(c)) {
                        throw std::runtime_error("Invalid Cards File");
                    }
                }

                gang_num = std::stoi(string_cards.front() );
                string_cards.erase(string_cards.begin());
                if(gang_num < 2) {
                    throw std::runtime_error("Invalid Cards File");
                }
                std::vector<std::unique_ptr<Encounter>> temporary;
                readGang(string_cards, temporary, gang_num);
                v_cards.push_back(std::unique_ptr<Card>(new Gang(temporary)));
                continue;

            } else {
                throw std::runtime_error("Invalid Cards File");
            }
        }
    }

    if(v_cards.size() < 2){
        throw std::runtime_error("Invalid Cards File");
    }
    return true;
}
bool Mtmchkin::readGang(std::vector<std::string> &string_cards, std::vector<std::unique_ptr<Encounter>> &temporary,
                        int gang_num) {
    if (string_cards.size() == 0 && gang_num != 0) {
        throw std::runtime_error("Invalid Cards File");
    }
    if (gang_num == 0) {
        return true;
    }
    if (string_cards.front() == "Dragon") {
        temporary.push_back(std::unique_ptr<Encounter>(new Dragon()));
        string_cards.erase(string_cards.begin());
        readGang(string_cards, temporary, gang_num - 1);
    } else if (string_cards.front() == "Giant") {
        temporary.push_back(std::unique_ptr<Encounter>(new Giant()));
        string_cards.erase(string_cards.begin());
        readGang(string_cards, temporary, gang_num - 1);
    } else if (string_cards.front() == "Goblin") {
        temporary.push_back(std::unique_ptr<Encounter>(new Goblin()));
        string_cards.erase(string_cards.begin());
        readGang(string_cards, temporary, gang_num - 1);
    } else if (string_cards.front() == "SolarEclipse") {
        throw std::runtime_error("Invalid Cards File");
    } else if (string_cards.front() == "PotionsMerchant") {
        throw std::runtime_error("Invalid Cards File");
    } else {
        if (string_cards.front() == "Gang") {
            gang_num--;
            string_cards.erase(string_cards.begin());
            for (auto c: string_cards.front()) {
                if (!std::isdigit(c)) {
                    throw std::runtime_error("Invalid Cards File");
                }
            }

            int gang_num2 = std::stoi(string_cards.front());
            if (gang_num2 < 2) {
                throw std::runtime_error("Invalid Cards File");
            }
            string_cards.erase(string_cards.begin());

            std::vector<std::unique_ptr<Encounter>> temporary2;
            readGang(string_cards, temporary2, gang_num2);
            temporary.push_back(std::unique_ptr<Encounter>(new Gang(temporary2)));

            readGang(string_cards, temporary, gang_num);

        } else {
            throw std::runtime_error("Invalid Cards File");
        }

    }
    return true;
}

Mtmchkin::Mtmchkin(const string& deckPath, const string& playersPath) {
    std::vector<std::string> string_cards;
    /*===== TODO: Open and read cards file =====*/
    readWordsCards(deckPath , string_cards);
    readCardsFromFile( string_cards );
    /*==========================================*/


    /*===== TODO: Open and Read players file =====*/
    readPlayersFromFile(playersPath);
    /*============================================*/


    this->m_turnIndex = 1;
}

void Mtmchkin::playTurn(Player& player) {
    std::unique_ptr<Card> drawnCard = std::move(v_cards.front());
    v_cards.erase(v_cards.begin());

    printTurnDetails(m_turnIndex, player, *drawnCard);




    if (dynamic_cast<SolarEclipse*>(drawnCard.get())){
        if (player.getJob() == "Warrior") {

            if(player.getForce() == 0) {
                    printTurnOutcome(getSolarEclipseMessage(player, 0));
                drawnCard->applyEncounter(player);

            } else{
                printTurnOutcome(getSolarEclipseMessage(player, -1));
                drawnCard->applyEncounter(player);
            }
        } else {
            printTurnOutcome(getSolarEclipseMessage(player, 1));
            drawnCard->applyEncounter(player);
        }
    } else if(auto* potionsMerchantCard = dynamic_cast<PotionsMerchant*>(drawnCard.get())){
        drawnCard->applyEncounter(player);
        printTurnOutcome(getPotionsPurchaseMessage(player,potionsMerchantCard->getNumber()));

    } else if(auto* encounterCard = dynamic_cast<Encounter*>(drawnCard.get())){
        drawnCard->applyEncounter(player);
        int cardForce = encounterCard->getC_force();
        int cardDamage = encounterCard->getC_damage();
        int cardLoot = encounterCard->getC_reward();
        if(cardForce >= player.getCombatPower()){
            printTurnOutcome(getEncounterLostMessage(player, cardDamage));
        } else{
            printTurnOutcome(getEncounterWonMessage(player, cardLoot));
        }
    }
    v_cards.push_back(std::move(drawnCard));

    m_turnIndex++;
}

void Mtmchkin::playRound(std::vector<const Player*>& leaderBoard) {
    printRoundStart();

    for(const auto & v_player : v_players){
        if(v_player->isKnockedOut()){
            continue;
        }
        playTurn(*v_player);
    }




    std::sort(leaderBoard.begin(), leaderBoard.end(), [](const Player *a, const Player *b) {
        if (a->getLevel() != b->getLevel()) {
            return a->getLevel() > b->getLevel();
        }
        if (a->getCoins() != b->getCoins()) {
            return a->getCoins() > b->getCoins();
        }
        return a->getName() < b->getName();
    });

    printRoundEnd();
    printLeaderBoardMessage();
    int size = leaderBoard.size();
    for (int i = 0; i < size; ++i) {
        printLeaderBoardEntry(i + 1, *leaderBoard[i]);
    }

    printBarrier();
}

bool Mtmchkin::isGameOver() const {///v
    for(const auto & v_player : v_players){
        if(v_player->getLevel() == MAX_LEVEL){
            return true;
        }
    }
    for(const auto & v_player : v_players){
        if(v_player->getHealthPoints() != 0) {
            return false;
        }
    }
    return true;
}

void Mtmchkin::play() {
    printStartMessage();
    /*===== TODO: Print start message entry for each player using "printStartPlayerEntry" =====*/
    int size = v_players.size();
    for(int i = 0; i < size; i++){
        const Player& player = *v_players[i];
        printStartPlayerEntry(i + 1, player);
    }
    /*=========================================================================================*/
    std::vector<const Player*> leaderBoard;
    for(const auto& playerPtr : v_players){
        leaderBoard.push_back(playerPtr.get());
    }
    printBarrier();

    while (!isGameOver()) {
        playRound(leaderBoard);
    }

    printGameOver();
    /*===== TODO: Print either a "winner" message or "no winner" message =====*/

    if(leaderBoard[0]->getLevel() == MAX_LEVEL){
        printWinner(*leaderBoard[0]);
    } else{
        printNoWinners();
    }

    /*========================================================================*/
}