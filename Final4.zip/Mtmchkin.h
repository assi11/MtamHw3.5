#include <fstream>
#include <iostream>
#pragma once
#include <deque>  // no need
#include <string>
#include <memory>
#include <vector>
#include <queue> // no need
#include "Players/Player.h"
#include "Players/Warrior.h"
#include "Players/Sorcerer.h"
#include "Cards/Card.h"
#include "Cards/Dragon.h"
#include "Cards/Encounter.h"
#include "Cards/Event.h"
#include "Cards/Gang.h"
#include "Cards/Goblin.h"
#include "Cards/Giant.h"
#include "Cards/SolarEclipse.h"
#include "Cards/PotionsMerchant.h"

using std::string;
using std::shared_ptr;
using std::vector;
using std::queue; // no need

class Mtmchkin{
private:
    int m_turnIndex;
    std::vector<std::unique_ptr<Player>> v_players;
    std::vector<std::unique_ptr<Card>> v_cards;


    bool readWordsCards(const std::string& filename , std::vector<std::string>& string_cards);
    //reds the cars file as words and puts it in a private string vector
    bool readCardsFromFile( std::vector<std::string>& string_cards);
    // this takes the vector we created above and turns it into a cards victor
    /**
     * Plays a single turn for a player
     * 
     * @param player - the player to play the turn for
     * 
     * @return - void
    */
    void playTurn(Player& player);
    bool  readGang(std::vector<std::string>& string_cards,  std::vector<std::unique_ptr<Encounter>>& temporary,int gang_num);
    /**
     * Plays a single round of the game
     * 
     * @return - void
    */
    void playRound(std::vector<const Player*>& leaderBoard);

    /**
     * Checks if the game is over
     * 
     * @return - true if the game is over, false otherwise
    */
    bool isGameOver() const;

    int m_rounds;
    int m_players_size;

public:
    /**
     * Constructor of Mtmchkin class
     * 
     * @param deckPath - path to the deck file
     * @param playersPath - path to the players file
     * 
     * @return - Mtmchkin object with the given deck and players
     *
    */
    Mtmchkin(const string& deckPath, const string& playersPath);
    // Destructor
    ~Mtmchkin() = default;
    /**
     * Plays the entire game
     * 
     * @return - void
    */
    void play();

    /**
     * Deletes the spaces in the given str
     * @param str The string we want to "clean"
     */
     void removeExtraSpaces(std::string& str);

    /**
     * Count the number of words in the string
     * @param str the string we want to count the number in it
     * @returnThe number of the words in the str
     */
    int getNumOfWords(std::string& str);


    /**
     *
     * @param player_name The player's name
     * @param player_job The player's job
     * @param player_behavior The player's behavior
     * @param num_of_words The number of the words for each player
     * @return true if the input is valid, else returns false
     */

    /**
     * Reads the players from the file
     * @param filename the given file
     */
    void readPlayersFromFile( const std::string& filename);

    /**
     * Checks the player's name
     * @param name the player's name
     * @return true if the name is valid, else false.
     */
    bool isValidName(const std::string& name);


    void playRound(vector<shared_ptr<Player>> &leaderBoard);
};
