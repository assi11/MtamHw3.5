//
// Created by Mohanad Riead on 3/20/2024.
//

#ifndef CARDS_GIANT_H
#define CARDS_GIANT_H
#include "Encounter.h"

class Giant : public Encounter{

public:
    explicit Giant();
    string getDescription() const override;
};



#endif //CARDS_GIANT_H
