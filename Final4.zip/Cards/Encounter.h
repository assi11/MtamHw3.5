//
// Created by Mohanad Riead on 3/20/2024.
//

#ifndef CARDS_ENCOUNTER_H
#define CARDS_ENCOUNTER_H
#include "Card.h"

class Encounter : public Card{
protected:
    std :: string CardName ;
    int c_force;
    int c_damage;
    int c_reward;
public:
    Encounter(const std::string &CardName , int force=0, int reward=0, int damage=0);


     void applyEncounter (Player& player) override;
    virtual string getDescription() const= 0;
     int getC_force() const;
     int getC_reward() const;
     int getC_damage() const;
    std :: string getC_name() const;

};


#endif //CARDS_ENCOUNTER_H
