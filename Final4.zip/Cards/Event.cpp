//
// Created by Mohanad Riead on 3/20/2024.
//

#include "Event.h"

Event::Event(const std::string &name) : Card(name){}

string Event::getDescription() const {
    return m_name;   //why the name only
}
