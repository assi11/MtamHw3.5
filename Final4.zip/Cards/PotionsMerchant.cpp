//
// Created by Mohanad Riead on 3/21/2024.
//

const int HEALTH_COST = 5;
const int HEALTH_VALUE = 10;

#include "PotionsMerchant.h"

PotionsMerchant::PotionsMerchant() : Event("PotionsMerchant"), number(0) {}


void PotionsMerchant::applyEncounter ( Player& player){
number=0;
    if(player.getBehavior() == "Responsible"){
        while(player.getHealthPoints() < 100 && player.pay(HEALTH_COST)){
            player.heal(HEALTH_VALUE);
            number += 1;
        }
    }

    if(player.getBehavior() == "RiskTaking"){
        if(player.getHealthPoints() < 50 && player.pay(HEALTH_COST)){
            player.heal(HEALTH_VALUE);
            number++;
        }
    }
}

int& PotionsMerchant::getNumber()  {
    return number;
}
