//
// Created by Mohanad Riead on 3/20/2024.
//

#ifndef CARDS_EVENT_H
#define CARDS_EVENT_H

#include "Card.h"

class Event : public Card{


public:
    explicit Event(const std::string &name);
    string getDescription() const override;

     //void applyEncounter (Player& player) const override;

};


#endif //CARDS_EVENT_H
