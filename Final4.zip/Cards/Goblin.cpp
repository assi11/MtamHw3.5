//
// Created by Mohanad Riead on 3/20/2024.
//

const int GOBLIN_FORCE= 5;
const int GOBLIN_REWARD = 2;
const int GOBLIN_DAMAGE = 10;

#include "Goblin.h"
Goblin::Goblin() :
            Encounter("Goblin", GOBLIN_FORCE,GOBLIN_DAMAGE,GOBLIN_REWARD ){}

string Goblin::getDescription() const {
    std::string str = "Goblin (power " + std::to_string(this->getC_force()) +
                      ", loot " + std::to_string(this->getC_reward()) +
                      ", damage " + std::to_string(this->getC_damage()) + ")";
    return str;
}

