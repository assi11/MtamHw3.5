//
// Created by Mohanad Riead on 3/21/2024.
//
static const int ADD_HEALTH = 1;

#include "SolarEclipse.h"



SolarEclipse::SolarEclipse() : Event("SolarEclipse") {}

void SolarEclipse::applyEncounter(Player &player)  {

    if(player.getJob() == "Sorcerer"){
        player.buff(ADD_HEALTH);
    }

    if(player.getJob() == "Warrior"){
        player.buff(-ADD_HEALTH);
    }
}

