//
// Created by Mohanad Riead on 3/20/2024.
//

#include "Giant.h"
const int GIANT_FORCE = 12;
const int GIANT_REWARD = 5;
const int GIANT_DAMAGE = 25;
Giant::Giant() :
        Encounter("Giant", GIANT_FORCE, GIANT_DAMAGE, GIANT_REWARD){}


string Giant::getDescription() const {
    std::string str = "Giant (power " + std::to_string(this->getC_force()) +
                      ", loot " + std::to_string(this->getC_reward()) +
                      ", damage " + std::to_string(this->getC_damage()) + ")";
    return str;
}