//
// Created by Mohanad Riead on 3/20/2024.
//

#include "Gang.h"
#include "vector"

Gang::Gang(std::vector<std::unique_ptr<Encounter>>& monsters):Encounter("Gang", 0, 0, 0)
{

   for(auto& m: monsters){
   this->m_monsters.push_back(std::move(m));
   }
    this->c_damage=calculateTotalDamage();
   this->c_force=calculateTotalPower();
   this->c_reward=calculateTotalLoot();
}



int Gang::calculateTotalPower() const{
    int totalPower = 0;
    for (auto &monster : this->m_monsters) {
        totalPower += monster->getC_force();
    }
    return totalPower;
}

int Gang::calculateTotalLoot() const {
    int totalLoot = 0;
    for (auto &monester: this->m_monsters) {
        totalLoot += monester->getC_reward();
    }
    return totalLoot;
}

int Gang::calculateTotalDamage() const {
    int totalDamage = 0;
    for (auto& monster : this->m_monsters) {
        totalDamage += monster->getC_damage();
    }
    return totalDamage;
}

std::string Gang::getDescription() const {
    int totalPower = calculateTotalPower();
    int totalLoot = calculateTotalLoot();
    int totalDamage = calculateTotalDamage();

    std::string description = "Gang of " + std::to_string(m_monsters.size()) +
                              " members (power " + std::to_string(totalPower) +
                              ", loot " + std::to_string(totalLoot) +
                              ", damage " + std::to_string(totalDamage) + ")";
    return description;
}





