//
// Created by Mohanad Riead on 3/21/2024.
//

#ifndef CARDS_SOLARECLIPSE_H
#define CARDS_SOLARECLIPSE_H
#include "Event.h"

class SolarEclipse : public Event {

    void applyEncounter (Player& player)  override;

public:
    explicit SolarEclipse();
};


#endif //CARDS_SOLARECLIPSE_H
