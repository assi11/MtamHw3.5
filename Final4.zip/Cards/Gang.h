//
// Created by Mohanad Riead on 3/20/2024.
//

#ifndef CARDS_GANG_H
#define CARDS_GANG_H
#include <memory>
#include <vector>
#include "Encounter.h"

class Gang : public Encounter{


    std::vector<std::unique_ptr<Encounter>> m_monsters;

    int calculateTotalPower()const;
    int calculateTotalLoot()const;
    int calculateTotalDamage() const;
public:
    explicit Gang(std::vector<std::unique_ptr<Encounter>>& monsters);
    string getDescription() const override;

};


#endif //CARDS_GANG_H
