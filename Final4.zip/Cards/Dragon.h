//
// Created by Mohanad Riead on 3/20/2024.
//

#ifndef CARDS_DRAGON_H
#define CARDS_DRAGON_H
#include "Encounter.h"

class Dragon : public Encounter{
private :

public:
    explicit Dragon();

    string getDescription() const override;
};


#endif //CARDS_DRAGON_H
