//
// Created by Mohanad Riead on 3/20/2024.
//

#include "Dragon.h"
const int DRAGON_FORCE = 17;
const int DRAGON_REWARD = 100;
const int DRAGON_DAMAGE = 9001;
    Dragon:: Dragon():
    Encounter("Dragon", DRAGON_FORCE, DRAGON_DAMAGE, DRAGON_REWARD){}

string Dragon::getDescription() const {
    std::string str = "Dragon (power " + std::to_string(this->getC_force()) +
                      ", loot " + std::to_string(this->getC_reward()) +
                      ", damage " + std::to_string(this->getC_damage()) + ")";
    return str;
}
