//
// Created by Mohanad Riead on 3/20/2024.
//

#include <iostream>
#include "Encounter.h"
#include "Warrior.h"
class Warrior;
Encounter::Encounter(const std::string &CardName , int force, int damage, int reward):
         Card(CardName), c_force(force), c_damage(damage), c_reward(reward){}

void Encounter::applyEncounter(Player &player){
    if(player.getJob() == "Warrior") {

        if(2 * player.getForce() + player.getLevel() > c_force){
            player.levelUp();
            player.addCoins(c_reward);
        }
        else{
            player.damage(c_damage);
        }

    } else{
        if(player.getForce() + player.getLevel() > c_force){
            player.levelUp();
            player.addCoins(c_reward);
        }
        else{
            player.damage(c_damage);
        }
    }
}

int Encounter ::  getC_force() const {
    return c_force ;
}
int Encounter :: getC_reward() const {
    return c_reward;
}
int Encounter :: getC_damage() const{
    return c_damage;
}
std :: string Encounter :: getC_name() const{
    return this->CardName ;
}


