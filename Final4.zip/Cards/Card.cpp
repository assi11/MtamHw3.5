//
// Created by Mohanad Riead on 3/20/2024.
//

#include "Card.h"


Card::Card(const std::string &card_name){
    m_name = card_name;
}


