//
// Created by Mohanad Riead on 3/21/2024.
//

#ifndef CARDS_POTIONSMERCHANT_H
#define CARDS_POTIONSMERCHANT_H

#include "Event.h"
class PotionsMerchant : public Event {
private:
    int number;
public:
    explicit PotionsMerchant();

    void applyEncounter ( Player& player) override;
    int& getNumber() ;
};


#endif //CARDS_POTIONSMERCHANT_H
