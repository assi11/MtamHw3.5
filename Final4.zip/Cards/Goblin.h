//
// Created by Mohanad Riead on 3/20/2024.
//

#ifndef CARDS_GOBLIN_H
#define CARDS_GOBLIN_H
#include "Encounter.h"

class Goblin : public Encounter{
public:
    explicit Goblin();


    string getDescription() const override;
};



#endif //CARDS_GOBLIN_H
