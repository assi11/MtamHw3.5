//
// Created by Mohanad Riead on 3/20/2024.
//
#pragma once

#include "../Players/Player.h"

class Card{
public:

    /**
     * C'Tors & D'Tors
     */
    explicit Card(const std::string &name);
    Card(const Card& other) = default;
    virtual ~Card() = default;
    /**
     * Gets the description of the card
     *
     * @return - the description of the card
    */
    virtual string getDescription() const = 0;
    virtual void applyEncounter ( Player& player) = 0;

protected:
    std::string m_name;
};




